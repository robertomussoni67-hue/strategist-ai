# -*- coding: utf-8 -*-
# Motore di Analisi ETF/Portafoglio - versione base

import pandas as pd
import numpy as np

# ---------------------------
# 1. Profilazione Investitore
# ---------------------------
class ProfiloInvestitore:
    def __init__(self, nome, eta, capitale_iniziale, pac_mensile, orizzonte_anni, obiettivi, rischio, regime_fiscale):
        self.nome = nome
        self.eta = eta
        self.capitale_iniziale = capitale_iniziale
        self.pac_mensile = pac_mensile
        self.orizzonte_anni = orizzonte_anni
        self.obiettivi = obiettivi
        self.rischio = rischio
        self.regime_fiscale = regime_fiscale

# ---------------------------
# 2. Analisi Macroeconomica (placeholder)
# ---------------------------
def analisi_macro():
    # Qui importerai dati da fonti macro (es. inflazione, tassi interesse)
    return {"scenario": "difensivo", "commento": "Tassi stabili, crescita bassa"}

# ---------------------------
# 3. Screening ETF
# ---------------------------
class ETF:
    def __init__(self, nome, isin, ter, aum, strategia, payout_ratio, distribuzione, esg_score):
        self.nome = nome
        self.isin = isin
        self.ter = ter
        self.aum = aum
        self.strategia = strategia
        self.payout_ratio = payout_ratio
        self.distribuzione = distribuzione
        self.esg_score = esg_score

def filtra_etf(lista_etf, max_ter=0.6):
    return [etf for etf in lista_etf if etf.ter <= max_ter]

# ---------------------------
# 4. Analisi Quantitativa Avanzata
# ---------------------------
def analisi_quant(etf):
    return {
        "beta": round(np.random.uniform(0.6, 1.2), 2),
        "sharpe_ratio": round(np.random.uniform(0.5, 2.0), 2),
        "max_drawdown": round(np.random.uniform(-0.3, -0.1), 2)
    }

# ---------------------------
# 5. Report Finale
# ---------------------------
def crea_report(etf_filtrati):
    for etf in etf_filtrati:
        quant = analisi_quant(etf)
        print(f"ETF: {etf.nome} ({etf.isin})")
        print(f" TER: {etf.ter}% | AUM: {etf.aum}M | Strategia: {etf.strategia}")
        print(f" Payout Ratio: {etf.payout_ratio}% | Distribuzione: {etf.distribuzione}")
        print(f" ESG Score: {etf.esg_score}")
        print(f" Beta: {quant['beta']} | Sharpe: {quant['sharpe_ratio']} | Max DD: {quant['max_drawdown']}")
        print("----")

# ---------------------------
# ESEMPIO USO
# ---------------------------
if __name__ == "__main__":
    # Profilo demo
    profilo = ProfiloInvestitore("Sonia", 40, 50000, 500, 15, "rendita e crescita", "medio", "UCITS IT")
    
    # ETF demo
    lista = [
        ETF("SPDR S&P Euro Dividend Aristocrats", "IE00B9CQXS71", 0.3, 1200, "High Dividend", 55, "Trimestrale", 8.5),
        ETF("iShares Core MSCI World", "IE00B4L5Y983", 0.2, 40000, "Broad Market", 45, "Accumulazione", 9.0)
    ]
    
    filtrati = filtra_etf(lista)
    crea_report(filtrati)