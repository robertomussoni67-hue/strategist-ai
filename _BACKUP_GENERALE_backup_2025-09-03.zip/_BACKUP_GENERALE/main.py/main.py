import yfinance as yf
import pandas as pd
import matplotlib.pyplot as plt
from risk_engine import aggiungi_azienda

# =======================
# Funzioni di supporto
# =======================

def get_macro_data(ticker="^GSPC", period="6mo"):
    """Scarica i dati storici dal mercato (es. S&P500 di default)."""
    data = yf.download(ticker, period=period, interval="1d")
    return data

def calculate_indicators(df):
    """Aggiunge RSI e medie mobili al DataFrame."""
    # Media mobile a 20 e 50 giorni
    df['SMA20'] = df['Close'].rolling(window=20).mean()
    df['SMA50'] = df['Close'].rolling(window=50).mean()
    
    # Calcolo RSI
    delta = df['Close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    df['RSI'] = 100 - (100 / (1 + rs))
    
    return df

def detect_regime(df):
    """Rileva segnali di ipercomprato/ipervenduto in base all'RSI."""
    signals = []
    for idx, row in df.iterrows():
        if row['RSI'] > 70:
            signals.append((idx, 'Ipercomprato'))
        elif row['RSI'] < 30:
            signals.append((idx, 'Ipervenduto'))
    return signals

def plot_chart(df, ticker, signals):
    """Mostra grafico prezzi + medie mobili + segnali RSI."""
    plt.figure(figsize=(12, 6))
    plt.plot(df.index, df['Close'], label='Chiusura', color='blue')
    plt.plot(df.index, df['SMA20'], label='SMA20', color='orange', linestyle='--')
    plt.plot(df.index, df['SMA50'], label='SMA50', color='magenta', linestyle='--')

    for date, sig in signals:
        color = 'red' if sig == 'Ipercomprato' else 'green'
        plt.scatter(date, df.loc[date]['Close'], color=color, marker='o', s=100, label=sig)

    plt.title(f"Andamento {ticker}")
    plt.xlabel("Data")
    plt.ylabel("Prezzo")
    plt.legend()
    plt.grid(True)
    plt.show()

def generate_report(ticker="^GSPC"):
    """Genera un report semplice dei segnali più recenti."""
    data = get_macro_data(ticker)
    data = calculate_indicators(data)
    signals = detect_regime(data)

    latest = signals[-5:] if signals else []
    report_lines = [f"Ultimi segnali per {ticker}:"]
    for date, sig in latest:
        report_lines.append(f"{date.date()} → {sig}")
    return "\n".join(report_lines)

# =======================
# Integrazione con risk_engine
# =======================

def _safe_float(x, default=None):
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default

def _get_last_value(df, labels):
    """Prende il valore più recente per una delle etichette indicate."""
    if df is None or df.empty:
        return None
    for label in labels:
        if label in df.index:
            try:
                val = df.loc[label].iloc[0]
                return _safe_float(val, None)
            except Exception:
                continue
    return None

def _stima_crescita_fcf(cashflow_df):
    """Stima semplice del tasso di crescita FCF."""
    if cashflow_df is None or cashflow_df.empty:
        return 0.03
    labels_ocf = ['Total Cash From Operating Activities', 'Operating Cash Flow']
    labels_capex = ['Capital Expenditures', 'Investments in property, plant and equipment']
    try:
        ocf_row = next((cashflow_df.loc[l] for l in labels_ocf if l in cashflow_df.index), None)
        capex_row = next((cashflow_df.loc[l] for l in labels_capex if l in cashflow_df.index), None)
        if ocf_row is None or capex_row is None:
            return 0.03
        fcf_series = (ocf_row + capex_row).dropna()
        if len(fcf_series) >= 2:
            fcf_latest = _safe_float(fcf_series.iloc[0], None)
            fcf_prev = _safe_float(fcf_series.iloc[1], None)
            if fcf_latest is not None and fcf_prev and fcf_prev != 0:
                g = (fcf_latest / fcf_prev) - 1.0
                return max(min(g, 0.30), -0.20)
    except Exception:
        pass
    return 0.03

def _recupera_metriche_da_yf(ticker):
    """Recupera metriche base da Yahoo Finance per il risk_engine."""
    t = yf.Ticker(ticker)
    fin = t.financials
    bs = t.balance_sheet
    cf = t.cashflow

    ocf = _get_last_value(cf, ['Total Cash From Operating Activities', 'Operating Cash Flow'])
    capex = _get_last_value(cf, ['Capital Expenditures', 'Investments in property, plant and equipment'])
    fcf_attuale = ocf + capex if ocf is not None and capex is not None else None
    crescita = _stima_crescita_fcf(cf)

    debito_tot = _get_last_value(bs, ['Total Debt'])
    if debito_tot is None:
        short_debt = _get_last_value(bs, ['Short Long Term Debt', 'Short Term Debt'])
        long_debt = _get_last_value(bs, ['Long Term Debt'])
        if short_debt is not None or long_debt is not None:
            debito_tot = (short_debt or 0.0) + (long_debt or 0.0)

    patrimonio_netto = _get_last_value(bs, [
        'Total Stockholder Equity',
        'Total Shareholder Equity',
        'Total Equity Gross Minority Interest'
    ])

    att_correnti = _get_last_value(bs, ['Total Current Assets'])
    pass_correnti = _get_last_value(bs, ['Total Current Liabilities'])

    ebit = _get_last_value(fin, ['Ebit', 'EBIT'])
    oneri_fin = _get_last_value(fin, ['Interest Expense'])
    if oneri_fin is not None:
        oneri_fin = abs(oneri_fin)

    return {
        "fcf_attuale": fcf_attuale,
        "crescita": crescita,
        "debito_tot": debito_tot,
        "patrimonio_netto": patrimonio_netto,
        "att_correnti": att_correnti,
        "pass_correnti": pass_correnti,
        "ebit": ebit,
        "oneri_fin": oneri_fin
    }

def _analizza_titoli_e_scrivi_csv(tickers, anni=5, tasso_sconto=0.10, crescita_terminal=0.02):
    """Analizza i ticker e scrive i dati nel CSV tramite risk_engine."""
    if not tickers:
        print("⚠️ Nessun ticker fornito.")
        return
    print(f"🔎 Avvio analisi per: {', '.join(tickers)}")
    for idx, tk in enumerate(tickers, start=1):
        try:
            m = _recupera_metriche_da_yf(tk)
            if m["fcf_attuale"] is None:
                print(f"⚠️ {tk}: FCF non disponibile. Salto.")
                continue
            aggiungi_azienda(
                id_val=idx,
                nome=tk,
                fcf_attuale=m["fcf_attuale"],
                crescita=m["crescita"],
                anni=anni,
                tasso_sconto=tasso_sconto,
                crescita_terminal=crescita_terminal,
                debito_tot=m["debito_tot"],
                patrimonio_netto=m["patrimonio_netto"],
                att_correnti=m["att_correnti"],
                pass_correnti=m["pass_correnti"],
                ebit=m["ebit"],
                oneri_fin=m["oneri_fin"],
                indice_rischio=None,
                percorso_csv="analisi_aziende.csv"
            )
        except Exception as e:
            print(f"❌ Errore con {tk}: {e}")

# =======================
# Funzione principale
# =======================

def execute_macro(command):
    if command == "start":
        ticker = "^GSPC"  # S&P 500 di default
        data = get_macro_data(ticker)
        data = calculate_indicators(data)
        signals = detect_regime(data)
        plot_chart(data, ticker, signals)

    elif command == "report":
        print(generate_report("^GSPC"))

    elif command == "analizza":
        # Lista di esempio — puoi cambiarla o leggerla da