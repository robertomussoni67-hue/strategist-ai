import pandas as pd

def analizza_portafoglio(percorso_csv):
    df = pd.read_csv(percorso_csv)
    print("Prime righe del portafoglio:\n", df.head(), "\n")

    # Calcola il valore totale se colonne presenti
    if {'Quantità', 'Prezzo Attuale'}.issubset(df.columns):
        df['Valore'] = df['Quantità'] * df['Prezzo Attuale']
        valore_totale = df['Valore'].sum()
        print(f"💰 Valore totale portafoglio: {valore_totale:,.2f} €\n")

    # Calcola rendimento medio e top/flop se presente la colonna Rendimento %
    if 'Rendimento %' in df.columns:
        rendimento_medio = df['Rendimento %'].mean()
        print(f"📈 Rendimento medio: {rendimento_medio:.2f} %\n")

        top = df.sort_values('Rendimento %', ascending=False).head(3)
        flop = df.sort_values('Rendimento %').head(3)

        print("🏆 Top 3 titoli:\n", top[['ISIN', 'Rendimento %']], "\n")
        print("📉 Flop 3 titoli:\n", flop[['ISIN', 'Rendimento %']], "\n")

        perdita = df[df['Rendimento %'] < 0]
        if not perdita.empty:
            print("⚠️ Titoli in perdita:\n", perdita[['ISIN', 'Rendimento %']])
        else:
            print("🎉 Nessun titolo in perdita!")