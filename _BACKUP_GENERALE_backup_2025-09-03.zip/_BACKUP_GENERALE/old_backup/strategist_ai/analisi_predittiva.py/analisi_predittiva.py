import numpy as np
from sklearn.linear_model import LinearRegression

def stima_prezzo_futuro(prezzi_passati):
    X = np.arange(len(prezzi_passati)).reshape(-1, 1)
    y = np.array(prezzi_passati)
    modello = LinearRegression().fit(X, y)
    previsione = modello.predict([[len(prezzi_passati)]])
    return round(previsione[0], 2)

def calcola_momentum(prezzi, periodo=5):
    if len(prezzi) < periodo:
        return None
    media_corta = np.mean(prezzi[-periodo:])
    media_lunga = np.mean(prezzi)
    return "rialzista" if media_corta > media_lunga else "ribassista"
def calcola_momentum(prezzi):
    """
    Calcola il momentum come differenza percentuale
    tra l'ultimo prezzo e il primo.
    """
    if not prezzi or len(prezzi) < 2:
        return 0
    return round(((prezzi[-1] - prezzi[0]) / prezzi[0]) * 100, 2)