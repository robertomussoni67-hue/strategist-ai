import datetime

def analisi_dati_macro(eur_usd):
    """
    Analizza il tasso EUR/USD passato da stratega/main.py.
    Restituisce un dizionario con il valore e una valutazione di trend.
    """
    print("[AI] Analisi dati macro in corso...")
    if eur_usd is None:
        risultato = {"EUR/USD": None, "trend": "dati non disponibili"}
    elif eur_usd > 1.1:
        risultato = {"EUR/USD": eur_usd, "trend": "Euro forte"}
    elif eur_usd < 1.0:
        risultato = {"EUR/USD": eur_usd, "trend": "Euro debole"}
    else:
        risultato = {"EUR/USD": eur_usd, "trend": "Euro stabile"}

    print(f"[AI] Risultato analisi macro: {risultato}")
    return risultato


def analisi_azioni_etf(prezzi):
    """
    Analizza i prezzi di azioni/ETF in un dict {ticker: prezzo}.
    Restituisce un dizionario con fascia di prezzo.
    """
    print("[AI] Analisi titoli azionari in corso...")
    risultato = {}
    if not prezzi:
        print("[AI] Nessun dato titoli disponibile.")
        return risultato

    for ticker, prezzo in prezzi.items():
        if prezzo is None:
            stato = "n/d"
        elif prezzo > 200:
            stato = "alto"
        elif prezzo < 50:
            stato = "basso"
        else:
            stato = "medio"

        risultato[ticker] = {"prezzo": prezzo, "stato": stato}

    print(f"[AI] Risultato analisi titoli: {risultato}")
    return risultato


def analisi_notizie(news_list):
    """
    Analizza i titoli news (lista di stringhe) e filtra quelle rilevanti per finanza/mercati.
    """
    print("[AI] Analisi delle news in corso...")
    if not news_list:
        print("[AI] Nessuna news ricevuta.")
        return {"totali": 0, "rilevanti": []}

    parole_chiave = ["borsa", "inflazione", "tassi", "petrolio", "mercati", "dollaro", "euro"]
    rilevanti = [n for n in news_list if any(p.lower() in n.lower() for p in parole_chiave)]

    risultato = {
        "totali": len(news_list),
        "rilevanti": rilevanti
    }
    print(f"[AI] Risultato analisi news: {risultato}")
    return risultato


def estrai_macro_trend():
    """
    Legge e stampa i macro-trend dal file note_intelligence.txt.
    """
    try:
        with open("../Strategist_Doc/Docs/note_intelligence.txt", "r", encoding="utf-8") as f:
            contenuto = f.read()
            print("[AI] Macro-trend estratti dal file:")
            print(contenuto)
    except FileNotFoundError:
        print("[AI] File note_intelligence.txt non trovato.")


def avvia_ai(eur_usd, prezzi, news):
    """
    Funzione principale richiamata da stratega/main.py.
    Riceve i dati reali e coordina le varie analisi.
    """
    print("\n=== Avvio modulo Stratega AI ===")
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[AI] Timestamp avvio analisi: {timestamp}")

    macro = analisi_dati_macro(eur_usd)
    azioni = analisi_azioni_etf(prezzi)
    notizie = analisi_notizie(news)
    estrai_macro_trend()

    print("[AI] Analisi completata. Sintesi finale:")
    print(f" - Macro: {macro}")
    print(f" - Azioni/ETF: {azioni}")
    print(f" - News: {notizie}")
    print("=== Fine modulo Stratega AI ===\n")